SEE KHNAA — Phone-first starter prototype

WHAT THIS IS
A responsive web-app/PWA prototype. It is not yet a production app:
- The home screen, search, category filters, language selector, navigation and lesson-preview interactions work.
- Lesson cards are sample placeholders, not real videos.
- No accounts, cloud database, admin upload panel, analytics, payments or real video streaming are connected yet.

FILES
- index.html: app interface and interactions
- manifest.json: installable web-app metadata
- sw.js: basic offline caching
- icon.svg: starter app icon

TEST ON ANDROID
1. Extract this ZIP using your phone's Files app.
2. Open index.html in Acode or another HTML editor and use Preview.
3. For proper install-to-home-screen testing, host the folder on HTTPS (for example GitHub Pages), open the hosted link in Chrome, tap ⋮, then Add to Home screen / Install app.

NEXT DEVELOPMENT STAGES
1. Publish this prototype to a private test URL.
2. Add Firebase Authentication and Firestore for users, courses and progress.
3. Build a secure admin workflow for uploading original videos and course metadata.
4. Use a video host/CDN suitable for streaming; do not store large video files directly in Firestore.
5. Add subtitles/dubbing and translated UI strings language by language.
6. Test privacy, content moderation, accessibility and performance before public launch.

BRAND / LEGAL
SEE KHNAA is a working name only. Check Indian trademarks, Google Play names and domains before public launch.
